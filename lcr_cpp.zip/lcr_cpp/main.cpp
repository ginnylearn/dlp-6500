/*****************************************************************************
**             TEXAS INSTRUMENTS PROPRIETARY INFORMATION
**
**  (c) Copyright, Texas Instruments Incorporated, 2012-2013.
**      All Rights Reserved.
**
**  Property of Texas Instruments Incorporated. Restricted Rights -
**  Use, duplication, or disclosure is subject to restrictions set
**  forth in TI's program license agreement and associated documentation.
******************************************************************************/
/**
*
* @file    main.c
*
* @brief	This file contatins main() function from where the DM365 Command Interfaces
*			can be called.
*			This file also contain demo example functions which shows how the APIs can be
*			called in sequence.
**/
/*****************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include "error.h"

#include "BMPParser.h"
#include "API.h"
#include "string.h"
#include "usb.h"
//#include "version.h"
#include "firmware.h"
#include "splash.h"
#include "flashloader.h"
//#include "PtnImage.h"
#include "batchfile.h"
#include <string.h>

#define false 0
#define true 1
void mSleep(unsigned long int mSeconds);
int ReadLightCrafterVersion();
int RunBatch(int argc, char *argv[]);
int RunRawCmd(int argc, char *argv[]);

/* main() function */
int main(int argc, char *argv[])
{
    USB_Init();
    if(USB_IsConnected() == false)
    {
        USB_Open();
    }

    if (argc==1)
    {
        printf("Usage: LCR_API('version') -- Display software version \n");
        printf("Usage: LCR_API('LoadSequences',NumPatterns, TriggerDelay, TriggerType,TriggerPeriod, ExposureTime, dirnmae ) -- Get Current Display Mode \n");
    }
    else if (argc > 1)
    {
        char *option;
        int buflen;
        /* Allocate enough memory to hold the converted string. */
        buflen = strlen(argv[1]) + 1;
        option = (char *) calloc(buflen, sizeof(char));
        /* Copy the string data from prhs[0] and place it into option. */
        strncpy(option, argv[1], buflen);
        if (!strcmp("version",option))
            ReadLightCrafterVersion();
            //printf( "ReadLightCrafterVersion()\n");
        else if (!strcmp("GetDisplayMode",option))
            printf( "GetDisplayMode()\n");
            //GetDisplayMode();
        else if (!strcmp("RunBatch",option))
        {
            if (argc < 2)
                printf("Usage: LCR_API RunBatch Batach_ID) -- Get Current Display Mode \n");
            else
                RunBatch(argc,argv);
                //mSleep(5000);
        }

        else if (!strcmp("RunBatch",option))
        {
            if (argc < 2)
                printf("Usage: LCR_API RunRawCmd CMD_NAME PARM1 PARM2...) -- Get Current Display Mode \n");
            else
                RunRawCmd(argc,argv);
                //mSleep(5000);
        }
        free(option);
    }

    USB_Close();
    USB_Exit();
    return 0;
}

void mSleep(unsigned long int mSeconds)
{
	/*Add logic and call system function that will create mSeconds millisecond delay */
    usleep(mSeconds*1000);
}
int ReadLightCrafterVersion()
{
    char firmwareTag[32];
    unsigned int firmwareType;
    //char resolutionText[32];
    if(LCR_GetFrmwVersion(&firmwareType,firmwareTag)==0)
    {
            printf("firmwareTag: %s\n",firmwareTag);
            if(firmwareType == 2) //WQXGA firmware
            {
                printf("resolution: WQXGA\n");
            }
            else if(firmwareType == 1) //1080p firmware
            {
                printf("resolution: 1080p\n");
            }
            else if(firmwareType == 0) //Unknown
            {
                printf("resolution: Unknown Firmware detected!\n");
            }
    }
    return 0;
}

int RunBatch(int argc, char *argv[])
{
    int id;
    char *End;
    id = strtol(argv[2], &End, 0);
    if(*End != 0 || id > 0xFF)
    {
        printf("Invalid command data : %s\n", argv[2]);
        return -1;
    }

    if(LCR_executeBatchFile(id & 0xFF)==0)
    {
        printf("executing batchfile: %d failed!\n", id);
        return -1;
    }
    return 0;
}

int RunRawCmd(int argc, char *argv[])
{
    uint16 USBCmd;
    //uint08 *Data;
    char *Token;
    char const *CmdStr;
    uint16 Index;
    static uint08 Payload[512];
    uint08 CmdNum;
    if(API_GetI2CCommand(argv[2], &CmdNum) == -1)
    {
        //printf("Invalid command name : %s\n", Token);
        return -1;
    }
    if(API_GetCommandName(CmdNum, &CmdStr))
    {
        //printf("Invalid command name : %s\n", Token);
        return -1;
    }
    Index = 0;
    for (int i=3;i<argc; i++)
    {
        char *End;
        int Value;
        Value = strtol(argv[i], &End, 0);
        if(*End != 0 || Value > 0xFF)
        {
            printf("Invalid command data : %s\n", argv[i]);
            return -1;
        }
        if(Index >= ARRAY_SIZE(Payload))
        {
            printf("Too many bytes in payload : %s\n", CmdStr);
            return -1;
        }

        Payload[Index++] = Value;
    }
    if(API_GetUSBCommand(CmdStr, &USBCmd))
    {
        printf("Invalid command name : %s\n",CmdStr);
        return -1;
    }
    if(LCR_ExecuteRawCommand(USBCmd, Payload, Index) < 0)
    {
        printf( "Error: Raw Cmd execution failed\n");
        return -1;
    }
    return 0;
}
